# AI Wound Monitoring System

## Quick Start
- Frontend: React app with camera
- Backend: Python Flask API  
- AI: Basic wound analysis with OpenCV

## Team Roles
- Frontend Developer: React, Camera, UI
- Backend Developer: Flask API, Database
- ML Engineer: Image analysis, Wound detection
- Designer: UI/UX, Styling

## Goal
Create a working demo that can:
1. Take photos with phone camera
2. Analyze wound healing progress
3. Show results and track over time